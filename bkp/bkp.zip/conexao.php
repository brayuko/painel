<?php 
//definir fuso horario
date_default_timezone_set('America/Sao_Paulo');
//conexão local
    $servidor = 'localhost';
    $banco = 'markteplace';
    $usuario = 'root';
    $senha = '1qa2ws@23';

    try {
        $pdo = new PDO("mysql:dbname=$banco;host=$servidor;charset=utf8", "$usuario", "$senha");
       // echo "Conexão do banco de dados efetuado com sucesso!";
    } catch (Exception $e){
        echo "Erro ao conectar ao banco de dados!<br><br>";
        echo $e;
    }
   //VARIAVEIS GLOBAIS

   $nome_sistema = 'nome sistema';
   $email_sistema = 'omeuemailbkp@gmail.com';

?>