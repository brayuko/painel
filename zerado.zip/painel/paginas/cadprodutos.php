<?php

$pag = 'usuarios';
?>
<button type="button" class="btn btn-primary"><span class="fa fa-plus"></span>Novo Produto</button>

<div class="bs-example widget-shadow" style="padding: 15px;" id="listar">
    conteudo

</div>